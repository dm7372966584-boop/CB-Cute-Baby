# CB Cute Baby — Android starter project

A small native Android starter app using Kotlin + Jetpack Compose, with a red/black theme.

## Included
- Home screen with sample community cards
- Search and Online/All filters
- Profile detail screen
- Create/edit profile form (local demo state only)
- Notifications screen
- Safety screen with block/report guidance
- No real accounts, chat, calls, payments, or backend are connected

## Safety scope
This starter is designed as an age-appropriate community prototype. It does not include dating, adult services, paid calls, or unrestricted contact with strangers. Before any public launch, add age-appropriate safeguards, moderation, privacy controls, reporting workflows, and a properly secured backend.

## Build an APK
1. Install Android Studio (current stable) and the Android SDK.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

The APK is not prebuilt in this package because an Android SDK/Gradle build environment is required.

## Requirements
- Android Studio with a compatible JDK
- Android SDK 35
- Internet connection for the first Gradle dependency sync
