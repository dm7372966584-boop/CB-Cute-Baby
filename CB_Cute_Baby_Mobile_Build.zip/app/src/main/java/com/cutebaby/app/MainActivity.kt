package com.cutebaby.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF111111)
private val Panel = Color(0xFF202020)
private val Red = Color(0xFFE50922)
private val Muted = Color(0xFFBDBDBD)

data class Member(val name: String, val city: String, val online: Boolean, val about: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CuteBabyApp() }
    }
}

@Composable
fun CuteBabyApp() {
    val members = remember {
        listOf(
            Member("Aabha", "Jaipur", true, "Hello! I enjoy art, music and meeting new friends."),
            Member("Radhika", "Ajmer", true, "I like books, nature and creative hobbies."),
            Member("Priya", "Kota", false, "Here to share hobbies and positive conversations."),
            Member("Neha", "Udaipur", true, "I enjoy photography and learning new things.")
        )
    }
    var screen by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf(members.first()) }
    var query by remember { mutableStateOf("") }
    var onlineOnly by remember { mutableStateOf(false) }
    var displayName by remember { mutableStateOf("Your name") }
    var about by remember { mutableStateOf("Tell the community about your hobbies.") }
    var message by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, background = Black, surface = Panel,
            onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Black,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Black).padding(16.dp)) {
                    Text("CB", color = Red, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("CUTE BABY  •  COMMUNITY", color = Muted, fontSize = 11.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Profile", "Alerts", "Safety").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item; message = "" },
                            icon = { Text(when(item) { "Home" -> "⌂"; "Profile" -> "◎"; "Alerts" -> "♢"; else -> "盾" }, color = Red) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                when (screen) {
                    "Home" -> {
                        Text("Discover community", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search profiles") },
                            singleLine = true
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FilterChip(selected = !onlineOnly, onClick = { onlineOnly = false }, label = { Text("All") })
                            Spacer(Modifier.width(8.dp))
                            FilterChip(selected = onlineOnly, onClick = { onlineOnly = true }, label = { Text("Online") })
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(members.filter {
                                it.name.contains(query, true) && (!onlineOnly || it.online)
                            }) { member ->
                                MemberCard(member) {
                                    selected = member
                                    screen = "Details"
                                }
                            }
                        }
                    }
                    "Details" -> {
                        Text("Community profile", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Text("👤", fontSize = 54.sp)
                        Text(selected.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("${selected.city} • ${if (selected.online) "Online" else "Offline"}", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        Text(selected.about)
                        Spacer(Modifier.height(18.dp))
                        Text("This demo does not enable private calls or direct messaging.", color = Muted)
                        Button(onClick = { screen = "Home" }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text("Back to profiles")
                        }
                    }
                    "Profile" -> {
                        Text("Create your profile", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        OutlinedTextField(displayName, { displayName = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(about, { about = it }, label = { Text("About your hobbies") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { message = "Profile saved in this local demo." }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text("Save profile")
                        }
                        if (message.isNotBlank()) Text(message, color = Color.Green)
                    }
                    "Alerts" -> {
                        Text("Notifications", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        InfoCard("Welcome to CB Cute Baby", "Complete your profile and read the community guidelines.")
                        InfoCard("Privacy reminder", "Only share information you are comfortable making public.")
                        InfoCard("Community rules", "Be respectful. Report harassment, impersonation or unsafe content.")
                    }
                    "Safety" -> {
                        Text("Safety center", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        InfoCard("Block and report", "Use reporting tools for unwanted or harmful interactions.")
                        InfoCard("Privacy", "Do not publish your phone number, home address, school or live location.")
                        InfoCard("Moderation", "A production app needs trained moderators and a secure report-review process.")
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
fun MemberCard(member: Member, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp))
            .clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).background(Color(0xFF343434), CircleShape), contentAlignment = Alignment.Center) {
            Text("👤", fontSize = 28.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(member.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(member.city, color = Muted, fontSize = 12.sp)
            Text(if (member.online) "● ONLINE" else "● OFFLINE",
                color = if (member.online) Color(0xFF35D07F) else Muted, fontSize = 11.sp)
        }
        Text("VIEW", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text(title, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Muted, fontSize = 13.sp)
    }
}
